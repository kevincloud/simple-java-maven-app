import json
import math
import os
from collections import defaultdict
from datetime import datetime, timezone, timedelta
from pprint import pprint
from time import strptime, strftime
from typing import Dict, List

import boto3
from dateutil.tz import tzutc


def lambda_handler(event, context):
    """
    AWS Lambda function handler.

    Args:
        event (dict): Event data passed to the Lambda function.
        context (object): Runtime information provided by AWS Lambda.

    Returns:
        dict: Response or result based on the event processed.
    """
    # Log the event for debugging purposes
    print("Received event:", json.dumps(event, indent=2))

    try:
        # Example: Process the event here
        if 'key' in event:
            # Your event handling logic
            processed_value = event['key'] * 2  # Example to process 'key' field
            return {
                'statusCode': 200,
                'body': json.dumps({'processed_value': processed_value}),
            }
        else:
            # Return a bad request response
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Invalid request, missing key'}),
            }

    except Exception as e:
        # Catch and log exceptions
        print(f"An error occurred: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)}),
        }


# EC2 (Kelly)
def fetch_ec2_usage_types(client: boto3.client, start_date: datetime, end_date: datetime) -> List[str]:
    """
    Fetch all available `USAGE_TYPE` values from AWS Cost Explorer.
    """
    start_date_str = start_date.strftime('%Y-%m-%d')
    end_date_str = (end_date + timedelta(days=1)).strftime('%Y-%m-%d')

    response = client.get_dimension_values(
        TimePeriod={'Start': start_date_str, 'End': end_date_str},
        Dimension='USAGE_TYPE'
    )

    return [item['Value'] for item in response['DimensionValues'] if 'BoxUsage' in item['Value']]


def fetch_ec2_cost_usage(client: boto3.client, start_date: datetime, end_date: datetime, tags: Dict[str, List[str]], usage_types: List[str],
                         group_by_tags: bool) -> Dict:
    """
    Fetch EC2 cost and usage data from AWS Cost Explorer.
    """
    start_date_str = start_date.strftime('%Y-%m-%d')
    end_date_str = (end_date + timedelta(days=1)).strftime('%Y-%m-%d')

    if group_by_tags:
        group_by = [{'Type': 'TAG', 'Key': k} for k in tags.keys()]
    else:
        group_by = [
            {'Type': 'DIMENSION', 'Key': 'SERVICE'},
        ]

    try:
        response = client.get_cost_and_usage(
            TimePeriod={'Start': start_date_str, 'End': end_date_str},
            Granularity='MONTHLY',
            Metrics=['UsageQuantity'],
            Filter={
                'And': [
                    {'Dimensions': {'Key': 'SERVICE', 'Values': ['Amazon Elastic Compute Cloud - Compute']}},
                    {'Dimensions': {'Key': 'USAGE_TYPE', 'Values': usage_types}},
                    {'Tags': {'Key': k, 'Values': v} for k, v in tags.items()}
                ]
            },
            GroupBy=group_by
        )
        return response
    except Exception as e:
        print("Error fetching cost and usage data:", e)
        return {}


def get_service_connections_ec2(session: boto3.session, start_date: datetime, end_date: datetime, tags: Dict[str, List[str]]) -> Dict:
    """
    Fetches AWS Cost Explorer data to estimate service connections for EC2 instances using LaunchDarkly.

    :param start_date: Start date for the query
    :param end_date: End date for the query
    :return: dict object containing the service connections total, and a breakdown by tag, grouped by month.
    """
    client = session.client('ce')

    usage_types = fetch_ec2_usage_types(client, start_date, end_date)
    usage = fetch_ec2_cost_usage(client, start_date, end_date, tags, usage_types, False)
    usage_by_tag = fetch_ec2_cost_usage(client, start_date, end_date, tags, usage_types, True)

    service_connections = {}

    if 'ResultsByTime' in usage:
        for month_data in usage['ResultsByTime']:
            month = month_data['TimePeriod']['Start'][:7]
            total_usage = sum(float(group['Metrics']['UsageQuantity']['Amount']) for group in month_data['Groups'])
            service_connection_total = round(total_usage / 730, 2)

            service_connections[month] = {
                "serviceConnectionUsageTotal": service_connection_total,
            }

    if 'ResultsByTime' in usage_by_tag:
        for month_data in usage_by_tag['ResultsByTime']:
            month = month_data['TimePeriod']['Start'][:7]

            service_connection_by_tag = {}
            for group in month_data['Groups']:
                tags = ','.join(group.get('Keys', []))
                tags = tags.replace('$', '=')
                service_connection_by_tag[tags] = round(float(group['Metrics']['UsageQuantity']['Amount']) / 730, 2)

            service_connections[month]["serviceConnectionUsageByTag"] = service_connection_by_tag

    return service_connections


# Fetch all cluster names
def get_all_eks_clusters(session: boto3.session):
    client = session.client('eks')
    clusters = []
    paginator = client.get_paginator('list_clusters')
    for page in paginator.paginate():
        clusters.extend(page['clusters'])
    return clusters


def get_service_connection_eks(session: boto3.session, start_date: datetime, end_date: datetime, tags: Dict[str, List[str]]):
    client = session.client('cloudwatch')

    clusters = get_all_eks_clusters(session)

    usage_averages = {}

    for cluster_name in clusters:
        response = client.get_metric_data(
            MetricDataQueries=[
                {
                    'Id': 'm1',
                    'MetricStat': {
                        'Metric': {
                            'Namespace': 'ContainerInsights',
                            'MetricName': 'pod_number_of_running_containers',
                            'Dimensions': [
                                {'Name': 'ClusterName', 'Value': cluster_name}
                            ]
                        },
                        'Period': 3600 * 24,  # Adjust based on granularity
                        'Stat': 'Average'
                    },
                    'ReturnData': True
                }
            ],
            StartTime=start_date,
            EndTime=end_date
        )

        for result in response['MetricDataResults']:
            for i, ts in enumerate(result['Timestamps']):
                month_str = ts.strftime('%Y-%m')
                day_total = result['Values'][i]
                day_totals = usage_averages.get(month_str, [])
                day_totals.append(day_total)
                usage_averages[month_str] = day_totals

    service_connection = {}
    for month, totals in usage_averages.items():
        service_connection[month] = {'serviceConnectionUsageTotal': round(sum(totals) / len(totals), 2)}

    return service_connection


def get_service_connections_lambda(session: boto3.session, start_date: datetime, end_date: datetime, tags: Dict[str, List[str]]):
    """
    Retrieve service connection metrics for AWS Lambda services from CloudWatch.

    :param session: Boto3 session object for AWS.
    :param start_date: The start date for the metrics query (datetime).
    :param end_date: The end date for the metrics query (datetime).
    :param tags: Key/Value pairs of tags to filter by.
    :return: Dictionary containing monthly usage totals and usage by tag.
    """
    client = session.client('cloudwatch')

    # Format dates
    start_date_str = start_date.strftime('%Y-%m-%dT%H:%M:%SZ')
    end_date_str = end_date.strftime('%Y-%m-%dT%H:%M:%SZ')

    response = client.get_metric_data(
        MetricDataQueries=[
            {
                'Id': 'lambda_duration',
                'MetricStat': {
                    'Metric': {
                        'Namespace': 'AWS/Lambda',
                        'MetricName': 'Duration',
                        'Dimensions': [
                            {
                                'Name': 'FunctionName',
                                'Value': 'catamorphic-accelerate-event-processor'
                            }
                        ],
                    },
                    'Period': 60 * 60 * 24,  # 1 Month
                    'Stat': 'Sum',
                },
                'ReturnData': True,
            }
        ],
        StartTime=start_date_str,
        EndTime=end_date_str,
    )

    usage_totals_seconds = {}
    for result in response['MetricDataResults']:
        for i, ts in enumerate(result['Timestamps']):
            month_str = ts.strftime('%Y-%m')
            day_total_seconds = result['Values'][1] / 1000
            month_total_seconds = usage_totals_seconds.get(month_str, 0) + day_total_seconds
            usage_totals_seconds[month_str] = month_total_seconds

    service_connection = {}

    for month, total in usage_totals_seconds.items():
        service_connection[month] = {'serviceConnectionUsageTotal': round(total / 2_628_000, 2)}

    return service_connection


# ECS (Gabe)
def get_all_ecs_clusters(ecs_client):
    """Get list of all ECS cluster names."""
    clusters = []
    paginator = ecs_client.get_paginator('list_clusters')
    for page in paginator.paginate():
        clusters.extend(page['clusterArns'])
    return [arn.split('/')[-1] for arn in clusters]


def get_average_tasks_by_month(cloudwatch_client, cluster_name: str, start_date: datetime, end_date: datetime, tags: Dict[str, List[str]]) -> Dict[str, float]:
    """Get average number of tasks per month for a cluster."""
    monthly_data = defaultdict(list)
    response = cloudwatch_client.get_metric_statistics(
        Namespace='ECS/ContainerInsights',
        MetricName='TaskCount',
        Dimensions=[{'Name': 'ClusterName', 'Value': cluster_name}],
        StartTime=start_date,
        EndTime=end_date,
        Period=28800,  # 8 hour periods
        Statistics=['Average']
    )
    for datapoint in response['Datapoints']:
        timestamp = datapoint['Timestamp']
        if isinstance(timestamp, str):
            timestamp = datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%SZ")
        month_key = timestamp.strftime("%Y-%m")
        monthly_data[month_key].append(datapoint['Average'])
    return {
        month: sum(values) / len(values) if values else 0
        for month, values in monthly_data.items()
    }


def get_containers_per_task(ecs_client, cluster_name: str) -> float:
    """Get the average number of containers per task definition."""
    services = []
    paginator = ecs_client.get_paginator('list_services')
    for page in paginator.paginate(cluster=cluster_name):
        services.extend(page['serviceArns'])
    if not services:
        return 0
    total_containers = 0
    total_task_defs = 0
    for i in range(0, len(services), 10):
        batch = services[i:i + 10]
        response = ecs_client.describe_services(cluster=cluster_name, services=batch)
        for service in response['services']:
            task_def_arn = service['taskDefinition']
            task_def = ecs_client.describe_task_definition(taskDefinition=task_def_arn)
            container_count = len(task_def['taskDefinition']['containerDefinitions'])
            total_containers += container_count
            total_task_defs += 1
    return total_containers / total_task_defs if total_task_defs > 0 else 0


def get_service_connections_ecs(session: boto3.session.Session, start_date: datetime, end_date: datetime, tags: Dict[str, List[str]]) -> Dict:
    """
    Calculate service connections for ECS across all clusters.
    Args:
        session: boto3 session
        start_date: start date for metrics
        end_date: end date for metrics
        tags: dictionary of tags (not used in current implementation)
    Returns:
        Dict with structure:
        {
            'ecs': {
                'YYYY-MM': {
                    'serviceConnectionUsageTotal': int
                }
            }
        }
    """
    ecs_client = session.client('ecs')
    cloudwatch_client = session.client('cloudwatch')
    # Get all clusters
    clusters = get_all_ecs_clusters(ecs_client)
    # Store results by month
    monthly_totals = defaultdict(float)
    for cluster_name in clusters:
        # Get average tasks per month
        avg_tasks = get_average_tasks_by_month(cloudwatch_client, cluster_name, start_date, end_date, {})
        # Get average containers per task
        avg_containers = get_containers_per_task(ecs_client, cluster_name)
        # Calculate total containers for each month
        for month, avg_task_count in avg_tasks.items():
            total_containers = avg_task_count * avg_containers
            monthly_totals[month] += total_containers
    # Format the result according to the specified structure
    result = {
        month: {
            'serviceConnectionUsageTotal': round(total, 2)  # Round to nearest integer
        }
        for month, total in monthly_totals.items()
    }
    return result


if __name__ == "__main__":
    aws_profile = os.environ['AWS_PROFILE']
    session1 = boto3.Session(profile_name=aws_profile)
    session2 = boto3.Session(profile_name='launchdarkly-shared-services_Viewer')

    start_date = datetime(2024, 10, 1, 0, 0, 0, tzinfo=tzutc())
    end_date = datetime(2025, 1, 31, 8, 59, 59, tzinfo=tzutc())

    ec2 = get_service_connections_ec2(session1, start_date, end_date, {'env': ['staging', 'catamorphic']})
    ecs = get_service_connections_ecs(session1, start_date, end_date, {})
    eks = get_service_connection_eks(session2, start_date, end_date, {})
    lda = get_service_connections_lambda(session1, start_date, end_date, {})

    totals = {
        'EC2': ec2,
        'ECS': ecs,
        'EKS': eks,
        'Lambda': lda,
    }

    print(json.dumps(totals, indent=2))
