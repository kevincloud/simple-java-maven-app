# IAM Policy for ld-service-connections Lambda Function

This repository contains an IAM policy that grants the necessary permissions for executing the `ld-service-connections.py` script as an AWS Lambda function.

## Policy Overview

The IAM policy (`iam-policy.json`) includes permissions for the following AWS services:

1. **AWS Cost Explorer (CE)**
   - `ce:GetDimensionValues` - To retrieve EC2 usage types
   - `ce:GetCostAndUsage` - To retrieve EC2 usage data

2. **CloudWatch**
   - `cloudwatch:GetMetricData` - To retrieve metrics for Lambda and EKS
   - `cloudwatch:GetMetricStatistics` - To retrieve metrics for ECS

3. **Lambda**
   - `lambda:ListFunctions` - To list all Lambda functions
   - `lambda:ListTags` - To retrieve tags for Lambda functions

4. **Amazon EKS**
   - `eks:ListClusters` - To list all EKS clusters
   - `eks:DescribeCluster` - To retrieve details about EKS clusters

5. **Amazon ECS**
   - `ecs:ListClusters` - To list all ECS clusters
   - `ecs:ListServices` - To list services in ECS clusters
   - `ecs:DescribeClusters` - To retrieve details about ECS clusters
   - `ecs:DescribeServices` - To retrieve details about ECS services
   - `ecs:DescribeTaskDefinition` - To retrieve details about ECS task definitions

6. **CloudWatch Logs**
   - `logs:CreateLogGroup` - To create log groups for Lambda function logs
   - `logs:CreateLogStream` - To create log streams for Lambda function logs
   - `logs:PutLogEvents` - To write logs to CloudWatch Logs

## How to Use

1. Create a new IAM policy in your AWS account using the JSON in `iam-policy.json`
2. Attach this policy to the IAM role used by your Lambda function
3. Ensure the Lambda function is configured to use this role

## Assumptions and Considerations

1. **Resource Scope**: The policy grants permissions to all resources (`"Resource": "*"`) for most services. In a production environment, you may want to restrict these permissions to specific resources.

2. **Cross-Account Access**: If your Lambda function needs to access resources in multiple AWS accounts, you'll need to set up cross-account roles and permissions.

3. **Cost Explorer Permissions**: Cost Explorer permissions are particularly sensitive as they provide access to billing data. Ensure these permissions are only granted to roles that require them.

4. **Least Privilege**: This policy follows the principle of least privilege by only granting the specific permissions needed for the script to function. However, you may want to further restrict permissions based on your specific use case.

5. **CloudWatch Logs**: The policy includes permissions for CloudWatch Logs, which are required for Lambda function logging. The resource pattern `arn:aws:logs:*:*:*` allows logging to any log group, which you may want to restrict.

## Customization

You can customize this policy based on your specific requirements:

1. **Resource Restrictions**: Add specific ARNs to the `Resource` field to restrict permissions to specific resources.
2. **Conditional Access**: Add conditions to restrict when and how these permissions can be used.
3. **Permission Boundaries**: Consider using permission boundaries to further restrict what the Lambda function can do.