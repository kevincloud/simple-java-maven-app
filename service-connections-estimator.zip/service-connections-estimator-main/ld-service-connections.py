"""
LaunchDarkly Service Connections in AWS Estimator

This module estimates Service Connections for various AWS services that might
connect to LaunchDarkly via a server-side SDK including EC2, ECS, EKS, and Lambda.

The Service Connections metric (SC) measures the amount of time LaunchDarkly server-side
SDKs are connected to LaunchDarkly, measured in units of months.
"""

import json
import logging
from collections import defaultdict
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any

import boto3

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Constants
HOURS_IN_MONTH = 730  # Average hours in a month (365 days / 12 months * 24 hours)
SECONDS_IN_MONTH = 2_628_000  # Average seconds in a month (730 hours * 60 minutes * 60 seconds)


class ServiceConnectionEstimator:
    """Base class for estimating service connections across AWS services."""

    @staticmethod
    def get_account_id(session: boto3.session.Session) -> str:
        """Get the AWS account ID from a session."""

        try:
            return session.client('sts').get_caller_identity()['Account']
        except Exception:
            return 'unknown'

    @staticmethod
    def filter_by_tags(resource_tags: Dict[str, str], filter_tags: Dict[str, List[str]]) -> bool:
        """Check if resource tags match filter tags."""

        if not filter_tags:
            return True

        for tag_key, tag_values in filter_tags.items():
            if tag_key in resource_tags and resource_tags[tag_key] in tag_values:
                return True  # Match found for any tag key/value pair

        return False  # No matches found for any filter tags


class ECSEstimator(ServiceConnectionEstimator):
    """Estimates service connections for Amazon Elastic Container Service (ECS).

    Estimated service connections are calculated using the average number of running tasks,
    and the number of containers running per task, per month.

    """

    @staticmethod
    def fetch_clusters(session: boto3.session.Session,
                       tags: Dict[str, List[str]]) -> Tuple[List[str], Dict[str, Dict[str, str]]]:
        """Fetches ECS cluster names, optionally filtered by tags.

        Args:
            session: A boto3 session
            tags: Tags to filter by

        Returns:
            Tuple of (list of cluster names, dict mapping cluster names to their tags)
        """

    def fetch_clusters(session: boto3.session.Session, tags: Dict[str, List[str]]) -> Tuple[
        List[str], Dict[str, Dict[str, str]]]:
        """Fetches ECS cluster names, with detailed tag filtering logs."""
        client = session.client('ecs')
        clusters = []

        paginator = client.get_paginator('list_clusters')
        for page in paginator.paginate():
            clusters.extend(page['clusterArns'])

        if not clusters:
            return [], {}

        cluster_names = []
        cluster_tags_dict = {}

        # Process in batches of 10 (AWS API limit)
        for i in range(0, len(clusters), 10):
            batch = clusters[i:i + 10]

            try:
                response = client.describe_clusters(clusters=batch, include=['TAGS'])

                for cluster in response['clusters']:
                    cluster_name = cluster['clusterName']
                    cluster_tags = {tag['key']: tag['value'] for tag in cluster.get('tags', [])}

                    if not tags:
                        cluster_names.append(cluster_name)
                        cluster_tags_dict[cluster_name] = cluster_tags
                    else:
                        matched = False
                        for tag_key, tag_values in tags.items():
                            if tag_key in cluster_tags and cluster_tags[tag_key] in tag_values:
                                matched = True
                                break

                        if matched:
                            cluster_names.append(cluster_name)
                            cluster_tags_dict[cluster_name] = cluster_tags
            except Exception as e:
                logger.error(f"Error describing cluster batch: {e}", exc_info=True)

        return cluster_names, cluster_tags_dict

    @staticmethod
    def get_average_tasks_by_month(session: boto3.session.Session, cluster_name: str,
                                   start_date: datetime, end_date: datetime) -> Dict[str, float]:
        """Gets the average number of tasks per month for a specific ECS cluster.

        Args:
            session: A boto3 session
            cluster_name: Name of the ECS cluster
            start_date: Start date
            end_date: End date

        Returns:
            Dictionary mapping months to average task counts
        """
        client = session.client('cloudwatch')

        # Store monthly data
        monthly_data = defaultdict(list)

        # Get TaskCount metrics
        response = client.get_metric_statistics(
            Namespace='ECS/ContainerInsights',
            MetricName='TaskCount',
            Dimensions=[{'Name': 'ClusterName', 'Value': cluster_name}],
            StartTime=start_date,
            EndTime=end_date,
            Period=28800,  # 8 hour periods
            Statistics=['Average']
        )

        # Process the metrics data
        for datapoint in response['Datapoints']:
            timestamp = datapoint['Timestamp']
            if isinstance(timestamp, str):
                timestamp = datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%SZ")
            month_key = timestamp.strftime("%Y-%m")
            monthly_data[month_key].append(datapoint['Average'])

        # Calculate monthly averages
        return {
            month: sum(values) / len(values) if values else 0
            for month, values in monthly_data.items()
        }

    @staticmethod
    def get_containers_per_task(session: boto3.session.Session, cluster_name: str) -> float:
        """Gets the average number of containers per task definition for a specific ECS cluster."""
        client = session.client('ecs')

        # Get all services in the cluster
        services = []
        try:
            paginator = client.get_paginator('list_services')
            for page in paginator.paginate(cluster=cluster_name):
                services.extend(page['serviceArns'])
        except Exception as e:
            logger.warning(f"Could not list services for cluster {cluster_name}: {str(e)}")
            return 0

        if not services:
            return 0

        # Count containers in each task definition
        total_containers = 0
        total_task_defs = 0

        for i in range(0, len(services), 10):  # Process in batches of 10
            batch = services[i:i + 10]
            try:
                response = client.describe_services(cluster=cluster_name, services=batch)

                for service in response['services']:
                    task_def_arn = service['taskDefinition']
                    task_def = client.describe_task_definition(taskDefinition=task_def_arn)
                    container_count = len(task_def['taskDefinition']['containerDefinitions'])
                    total_containers += container_count
                    total_task_defs += 1
            except Exception as e:
                logger.warning(f"Error processing task definitions for cluster {cluster_name}: {str(e)}")
                continue

        # Calculate average
        return total_containers / total_task_defs if total_task_defs > 0 else 0

    @classmethod
    def estimate(cls, sessions: List[boto3.session.Session], start_date: datetime,
                 end_date: datetime, tags: Dict[str, List[str]]) -> Dict[str, Any]:
        """Estimates ECS service connections by calculating average container count.

        Args:
            sessions: List of boto3 sessions for different accounts/regions
            start_date: Start date
            end_date: End date
            tags: Tags to filter and group by

        Returns:
            Dictionary with service connection estimates
        """
        combined_results = {}
        errors = []

        try:
            for session in sessions:
                try:
                    account_id = cls.get_account_id(session)
                    region = session.region_name
                    logger.info(f"Estimating ECS service connections for account {account_id} in region {region}")

                    # Get all ECS clusters with their tags, filtered by tags if specified
                    clusters, cluster_tags_dict = cls.fetch_clusters(session, tags)

                    monthly_totals = defaultdict(float)
                    monthly_by_tag = defaultdict(lambda: defaultdict(float))

                    for cluster_name in clusters:
                        avg_tasks = cls.get_average_tasks_by_month(session, cluster_name, start_date, end_date)
                        avg_containers = cls.get_containers_per_task(session, cluster_name)
                        cluster_tags = cluster_tags_dict.get(cluster_name, {})

                        # Calculate total containers for each month
                        for month, avg_task_count in avg_tasks.items():
                            total_containers = avg_task_count * avg_containers
                            monthly_totals[month] += total_containers

                            if tags:
                                for tag_key, tag_values in tags.items():
                                    if tag_key in cluster_tags and cluster_tags[tag_key] in tag_values:
                                        tag_string = f"{tag_key}={cluster_tags[tag_key]}"
                                        monthly_by_tag[month][tag_string] += total_containers

                    # Initialize account in results if we have data
                    if monthly_totals:
                        combined_results[account_id] = {}

                    # Add monthly data to results
                    for month, total in monthly_totals.items():
                        if month not in combined_results[account_id]:
                            combined_results[account_id][month] = {
                                'serviceConnectionUsageTotal': round(total, 2),
                                'serviceConnectionUsageByTag': {}
                            }
                        else:
                            combined_results[account_id][month]['serviceConnectionUsageTotal'] += round(total, 2)

                        # Add tag-specific data
                        for tag_string, tag_total in monthly_by_tag[month].items():
                            if tag_total > 0:
                                combined_results[account_id][month]['serviceConnectionUsageByTag'][tag_string] = round(
                                    tag_total, 2)

                except Exception as e:
                    account_id = "unknown"
                    region = session.region_name or "unknown"
                    try:
                        account_id = session.client('sts').get_caller_identity()["Account"]
                    except:
                        pass

                    error_msg = f"Error processing ECS data for account {account_id} in region {region}: {str(e)}"
                    logger.error(error_msg)
                    errors.append(error_msg)

            # Return error if no valid results
            if errors and not combined_results:
                return {'error': f"Failed to estimate ECS service connections: {'; '.join(errors)}"}

            # Add errors as warnings if we have some valid data
            if errors:
                combined_results['warnings'] = errors

            return combined_results

        except Exception as error:
            logger.exception("Exception in ECS estimation")
            return {'error': f"Failed to estimate ECS service connections: {str(error)}"}


class EKSEstimator(ServiceConnectionEstimator):
    """Estimates service connections for Amazon Elastic Kubernetes Service (EKS).

    Service connections are calculated as the average number of running containers for the month.
    """

    @staticmethod
    def fetch_clusters(session: boto3.session.Session,
                       tags: Dict[str, List[str]]) -> Tuple[List[str], Dict[str, Dict[str, str]]]:
        """Fetches EKS clusters, optionally filtered by tags.

        Args:
            session: A boto3 session
            tags: Tags to filter by

        Returns:
            Tuple of (list of cluster names, dict mapping cluster names to their tags)
        """
        client = session.client('eks')
        clusters = []
        cluster_tags_dict = {}

        paginator = client.get_paginator('list_clusters')
        for page in paginator.paginate():
            clusters.extend(page['clusters'])

        if not clusters:
            return [], {}

        if not tags:
            return clusters, cluster_tags_dict

        # Process each cluster to get its tags
        filtered_clusters = []
        for cluster_name in clusters:
            try:
                cluster_info = client.describe_cluster(name=cluster_name)
                cluster_tags = cluster_info['cluster'].get('tags', {})
                cluster_tags_dict[cluster_name] = cluster_tags

                for tag_key, tag_values in tags.items():
                    if tag_key in cluster_tags and cluster_tags[tag_key] in tag_values:
                        filtered_clusters.append(cluster_name)
                        break
            except Exception as e:
                logger.error(f"Error retrieving tags for cluster {cluster_name}: {str(e)}")
                continue

        return filtered_clusters, cluster_tags_dict

    @classmethod
    def estimate(cls, sessions: List[boto3.session.Session], start_date: datetime,
                 end_date: datetime, tags: Dict[str, List[str]]) -> Dict[str, Any]:
        """Estimates EKS service connections based on running container count.

        Args:
            sessions: List of boto3 sessions for different accounts/regions
            start_date: Start date
            end_date: End date
            tags: Tags to filter and group by

        Returns:
            Dictionary with service connection estimates
        """
        combined_results = {}
        errors = []

        try:
            for session in sessions:
                try:
                    account_id = cls.get_account_id(session)
                    region = session.region_name

                    logger.info(f"Estimating EKS service connections for account {account_id} in region {region}")

                    client = session.client('cloudwatch')

                    clusters, cluster_tags_dict = cls.fetch_clusters(session, tags)

                    # Store data by month for this account
                    usage_averages_by_month = defaultdict(list)
                    usage_by_tag_and_month = defaultdict(lambda: defaultdict(list))

                    for cluster_name in clusters:
                        response = client.get_metric_data(
                            MetricDataQueries=[
                                {
                                    'Id': 'm1',
                                    'MetricStat': {
                                        'Metric': {
                                            'Namespace': 'ContainerInsights',
                                            'MetricName': 'pod_number_of_running_containers',
                                            'Dimensions': [
                                                {'Name': 'ClusterName', 'Value': cluster_name}
                                            ]
                                        },
                                        'Period': 3600 * 24,  # 1 day
                                        'Stat': 'Average'
                                    },
                                    'ReturnData': True
                                }
                            ],
                            StartTime=start_date,
                            EndTime=end_date
                        )

                        cluster_tags = cluster_tags_dict.get(cluster_name, {})

                        for result in response['MetricDataResults']:
                            for i, ts in enumerate(result['Timestamps']):
                                month_str = ts.strftime('%Y-%m')
                                if i < len(result['Values']):
                                    day_total = result['Values'][i]
                                    usage_averages_by_month[month_str].append(day_total)

                                    if tags:
                                        for tag_key, tag_values in tags.items():
                                            if tag_key in cluster_tags:
                                                tag_value = cluster_tags[tag_key]
                                                if tag_value in tag_values:
                                                    tag_string = f"{tag_key}={tag_value}"
                                                    usage_by_tag_and_month[month_str][tag_string].append(day_total)

                    # Initialize the account in combined results if we have data
                    if usage_averages_by_month and account_id not in combined_results:
                        combined_results[account_id] = {}

                    # Process monthly data for this account
                    for month, values in usage_averages_by_month.items():
                        if values:  # Ensure we don't divide by zero
                            if month not in combined_results[account_id]:
                                combined_results[account_id][month] = {
                                    'serviceConnectionUsageTotal': round(sum(values) / len(values), 2),
                                    'serviceConnectionUsageByTag': {}
                                }
                            else:
                                # Add to existing total for this month (in case of multiple regions)
                                existing_total = combined_results[account_id][month]['serviceConnectionUsageTotal']
                                new_total = existing_total + round(sum(values) / len(values), 2)
                                combined_results[account_id][month]['serviceConnectionUsageTotal'] = new_total

                            # Add tag-specific averages
                            if month in usage_by_tag_and_month:
                                for tag_string, tag_values in usage_by_tag_and_month[month].items():
                                    if tag_values:  # Ensure we don't divide by zero
                                        tag_avg = round(sum(tag_values) / len(tag_values), 2)
                                        existing_tag_value = combined_results[account_id][month][
                                            'serviceConnectionUsageByTag'].get(tag_string, 0)
                                        combined_results[account_id][month]['serviceConnectionUsageByTag'][
                                            tag_string] = existing_tag_value + tag_avg

                except Exception as e:
                    account_id = "unknown"
                    region = session.region_name or "unknown"
                    try:
                        account_id = session.client('sts').get_caller_identity()["Account"]
                    except:
                        pass

                    error_msg = f"Error processing EKS data for account {account_id} in region {region}: {str(e)}"
                    logger.error(error_msg)
                    errors.append(error_msg)

            # Return error if no valid results
            if errors and not combined_results:
                return {'error': f"Failed to estimate EKS service connections: {'; '.join(errors)}"}

            # Add errors as warnings if we have some valid data
            if errors:
                combined_results['warnings'] = errors

            return combined_results

        except Exception as error:
            logger.exception("Exception in EKS estimation")
            return {'error': f"Failed to estimate EKS service connections: {str(error)}"}


class LambdaEstimator(ServiceConnectionEstimator):
    """Estimates service connections for AWS Lambda functions.

    Service connections are calculated using the duration metric of any relevant Lambda functions.
    """

    @classmethod
    def estimate(cls, sessions: List[boto3.session.Session], start_date: datetime,
                 end_date: datetime, tags: Dict[str, List[str]]) -> Dict[str, Any]:
        """Estimates Lambda service connections by analyzing CloudWatch metrics.

        Args:
            sessions: List of boto3 sessions for different accounts/regions
            start_date: Start date
            end_date: End date
            tags: Tags to filter and group by

        Returns:
            Dictionary with service connection estimates
        """
        combined_results = {}
        errors = []

        try:
            for session in sessions:
                try:
                    account_id = cls.get_account_id(session)
                    region = session.region_name

                    logger.info(f"Estimating Lambda service connections for account {account_id} in region {region}")

                    client = session.client('cloudwatch')
                    lambda_client = session.client('lambda')

                    start_date_str = start_date.strftime('%Y-%m-%dT%H:%M:%SZ')
                    end_date_str = end_date.strftime('%Y-%m-%dT%H:%M:%SZ')

                    # Get Lambda functions
                    functions_with_tags = []
                    paginator = lambda_client.get_paginator('list_functions')

                    for page in paginator.paginate():
                        for function in page['Functions']:
                            function_tags = lambda_client.list_tags(Resource=function['FunctionArn'])['Tags']
                            if tags and not cls.filter_by_tags(function_tags, tags):
                                continue

                            # Store function name along with its tags
                            functions_with_tags.append({
                                'name': function['FunctionName'],
                                'tags': function_tags
                            })

                    usage_by_month_and_tag = {}
                    usage_totals_seconds = {}

                    # Get metrics for each function
                    for function_info in functions_with_tags:
                        function_name = function_info['name']
                        function_tags = function_info['tags']

                        response = client.get_metric_data(
                            MetricDataQueries=[
                                {
                                    'Id': 'lambda_duration',
                                    'MetricStat': {
                                        'Metric': {
                                            'Namespace': 'AWS/Lambda',
                                            'MetricName': 'Duration',
                                            'Dimensions': [
                                                {
                                                    'Name': 'FunctionName',
                                                    'Value': function_name
                                                }
                                            ],
                                        },
                                        'Period': 60 * 60 * 24,  # 1 day
                                        'Stat': 'Sum',
                                    },
                                    'ReturnData': True,
                                }
                            ],
                            StartTime=start_date_str,
                            EndTime=end_date_str,
                        )

                        for result in response['MetricDataResults']:
                            for i, ts in enumerate(result['Timestamps']):
                                month_str = ts.strftime('%Y-%m')
                                if month_str not in usage_by_month_and_tag:
                                    usage_by_month_and_tag[month_str] = {}

                                if month_str not in usage_totals_seconds:
                                    usage_totals_seconds[month_str] = 0

                                # Convert milliseconds to seconds
                                if i < len(result['Values']):
                                    day_total_seconds = result['Values'][i] / 1000
                                    usage_totals_seconds[month_str] += day_total_seconds

                                    if tags:
                                        for tag_name, tag_values in tags.items():
                                            if tag_name in function_tags and function_tags[tag_name] in tag_values:
                                                tag_key = f"{tag_name}={function_tags[tag_name]}"

                                                if tag_key not in usage_by_month_and_tag[month_str]:
                                                    usage_by_month_and_tag[month_str][tag_key] = 0

                                                usage_by_month_and_tag[month_str][tag_key] += day_total_seconds

                    # Initialize account in results if we have data
                    if account_id not in combined_results and usage_totals_seconds:
                        combined_results[account_id] = {}

                    # Convert seconds to service connections
                    for month, total_seconds in usage_totals_seconds.items():
                        service_connection_value = round(total_seconds / SECONDS_IN_MONTH, 2)

                        if month not in combined_results[account_id]:
                            combined_results[account_id][month] = {
                                'serviceConnectionUsageTotal': 0,
                                'serviceConnectionUsageByTag': {}
                            }

                        combined_results[account_id][month]['serviceConnectionUsageTotal'] += service_connection_value

                        if month in usage_by_month_and_tag:
                            for tag_key, tag_seconds in usage_by_month_and_tag[month].items():
                                tag_service_connections = round(tag_seconds / SECONDS_IN_MONTH, 2)

                                if tag_key not in combined_results[account_id][month]['serviceConnectionUsageByTag']:
                                    combined_results[account_id][month]['serviceConnectionUsageByTag'][tag_key] = 0

                                combined_results[account_id][month]['serviceConnectionUsageByTag'][
                                    tag_key] += tag_service_connections

                except Exception as e:
                    account_id = "unknown"
                    region = session.region_name or "unknown"
                    try:
                        account_id = session.client('sts').get_caller_identity()["Account"]
                    except:
                        pass

                    error_msg = f"Error processing Lambda data for account {account_id} in region {region}: {str(e)}"
                    logger.error(error_msg)
                    errors.append(error_msg)

            # Return error if no valid results
            if errors and not combined_results:
                return {'error': f"Failed to estimate Lambda service connections: {'; '.join(errors)}"}

            # Add errors as warnings if we have some valid data
            if errors:
                combined_results['warnings'] = errors

            return combined_results

        except Exception as error:
            logger.exception("Exception in Lambda estimation")
            return {'error': f"Failed to estimate Lambda service connections: {str(error)}"}


class EC2Estimator(ServiceConnectionEstimator):
    """Estimates service connections for EC2 instances."""

    @staticmethod
    def fetch_usage_types(session: boto3.session.Session, start_date: str, end_date: str) -> List[str]:
        """Fetches all EC2 usage types from AWS Cost Explorer for a given time period.

        Args:
            session: A boto3 session
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format

        Returns:
            List of EC2 BoxUsage usage type strings
        """
        client = session.client('ce')

        response = client.get_dimension_values(
            TimePeriod={'Start': start_date, 'End': end_date},
            Dimension='USAGE_TYPE'
        )

        return [item['Value'] for item in response['DimensionValues'] if 'BoxUsage' in item['Value']]

    @staticmethod
    def fetch_usage_total(session: boto3.session.Session, start_date: str, end_date: str,
                          tags: Dict[str, List[str]], usage_types: List[str]) -> Dict[str, float]:
        """Fetches the total EC2 usage and converts to service connections.

        Args:
            session: A boto3 session
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            tags: Tags to filter by
            usage_types: EC2 usage types to filter by

        Returns:
            Dictionary mapping months to service connection values
        """
        client = session.client('ce')

        if not usage_types:
            logger.warning("No EC2 usage types found for the specified period.")
            return {}

        filter_conditions = [
            {'Dimensions': {'Key': 'SERVICE', 'Values': ['Amazon Elastic Compute Cloud - Compute']}},
            {'Dimensions': {'Key': 'USAGE_TYPE', 'Values': usage_types}}
        ]

        if tags:
            for k, v in tags.items():
                filter_conditions.append({'Tags': {'Key': k, 'Values': v}})

        response = client.get_cost_and_usage(
            TimePeriod={'Start': start_date, 'End': end_date},
            Granularity='MONTHLY',
            Metrics=['UsageQuantity'],
            Filter={
                'And': filter_conditions
            },
            GroupBy=[{'Type': 'DIMENSION', 'Key': 'SERVICE'}]
        )

        usage = {}

        if 'ResultsByTime' in response:
            for month_data in response['ResultsByTime']:
                ts = datetime.strptime(month_data['TimePeriod']['Start'], '%Y-%m-%d')
                month_str = datetime.strftime(ts, '%Y-%m')
                total_usage = sum(float(group['Metrics']['UsageQuantity']['Amount'])
                                  for group in month_data['Groups'])
                service_connection_total = round(total_usage / HOURS_IN_MONTH, 2)

                usage[month_str] = service_connection_total

        return usage

    @staticmethod
    def fetch_usage_by_tag(session: boto3.session.Session, start_date: str, end_date: str,
                           tags: Dict[str, List[str]], usage_types: List[str]) -> Dict[str, Dict[str, float]]:
        """Fetches EC2 usage grouped by tags.

        Args:
            session: A boto3 session
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            tags: Tags to group by
            usage_types: EC2 usage types to filter by

        Returns:
            Nested dictionary mapping months to tags to service connection values
        """
        client = session.client('ce')

        if not tags:
            return {}

        filter_conditions = [
            {'Dimensions': {'Key': 'SERVICE', 'Values': ['Amazon Elastic Compute Cloud - Compute']}},
            {'Dimensions': {'Key': 'USAGE_TYPE', 'Values': usage_types}}
        ]

        for k, v in tags.items():
            filter_conditions.append({'Tags': {'Key': k, 'Values': v}})

        group_by = [{'Type': 'TAG', 'Key': k} for k in tags.keys()]

        response = client.get_cost_and_usage(
            TimePeriod={'Start': start_date, 'End': end_date},
            Granularity='MONTHLY',
            Metrics=['UsageQuantity'],
            Filter={
                'And': filter_conditions
            },
            GroupBy=group_by
        )

        usage = {}

        if 'ResultsByTime' in response:
            for month_data in response['ResultsByTime']:
                ts = datetime.strptime(month_data['TimePeriod']['Start'], '%Y-%m-%d')
                month_str = datetime.strftime(ts, '%Y-%m')

                service_connection_by_tag = {}
                for group in month_data['Groups']:
                    tags_str = ','.join(group.get('Keys', []))
                    tags_str = tags_str.replace('$', '=')
                    service_connection_by_tag[tags_str] = round(
                        float(group['Metrics']['UsageQuantity']['Amount']) / HOURS_IN_MONTH, 2
                    )

                usage[month_str] = service_connection_by_tag

        return usage

    @classmethod
    def estimate(cls, sessions: List[boto3.session.Session], start_date: datetime,
                 end_date: datetime, tags: Dict[str, List[str]]) -> Dict[str, Any]:
        """Estimates EC2 service connections.

        Args:
            sessions: List of boto3 sessions for different accounts/regions
            start_date: Start date
            end_date: End date
            tags: Tags to filter and group by

        Returns:
            Dictionary with service connection estimates
        """
        combined_results = {}
        errors = []

        try:
            for session in sessions:
                try:
                    # Add one day to end_date to include usage on that day (Cost Explorer end date is exclusive)
                    start_date_str = start_date.strftime('%Y-%m-%d')
                    end_date_str = (end_date + timedelta(days=1)).strftime('%Y-%m-%d')

                    account_id = cls.get_account_id(session)
                    region = session.region_name

                    logger.info(f"Estimating EC2 service connections for account {account_id} in region {region}")

                    usage_types = cls.fetch_usage_types(session, start_date_str, end_date_str)
                    usage_totals = cls.fetch_usage_total(session, start_date_str, end_date_str, tags, usage_types)

                    # Initialize account in results if we have data
                    if account_id not in combined_results and usage_totals:
                        combined_results[account_id] = {}

                    # Add usage totals
                    for month, total in usage_totals.items():
                        if month not in combined_results[account_id]:
                            combined_results[account_id][month] = {"serviceConnectionUsageTotal": 0}
                        combined_results[account_id][month]["serviceConnectionUsageTotal"] += total

                    # Add usage by tag if specified
                    if tags:
                        usage_by_tag = cls.fetch_usage_by_tag(
                            session, start_date_str, end_date_str, tags, usage_types)

                        for month, by_tag in usage_by_tag.items():
                            if month not in combined_results[account_id]:
                                logger.warning(
                                    f"Error processing EC2 data for account {account_id} in region {region} "
                                    f"for {month}: Usage data found for tags but not in total"
                                )
                                combined_results[account_id][month] = {"serviceConnectionUsageTotal": 0}

                            # Initialize the by_tag dict if it doesn't exist
                            if "serviceConnectionUsageByTag" not in combined_results[account_id][month]:
                                combined_results[account_id][month]["serviceConnectionUsageByTag"] = {}

                            # Combine tag values
                            for tag_key, tag_value in by_tag.items():
                                existing_value = combined_results[account_id][month]["serviceConnectionUsageByTag"].get(
                                    tag_key, 0)
                                combined_results[account_id][month]["serviceConnectionUsageByTag"][
                                    tag_key] = existing_value + tag_value

                except Exception as e:
                    account_id = "unknown"
                    region = session.region_name or "unknown"
                    try:
                        account_id = session.client('sts').get_caller_identity()["Account"]
                    except:
                        pass

                    error_msg = f"Error processing EC2 data for account {account_id} in region {region}: {str(e)}"
                    logger.error(error_msg)
                    errors.append(error_msg)

            # Return error if no valid results
            if errors and not combined_results:
                return {'error': f"Failed to estimate EC2 service connections: {'; '.join(errors)}"}

            # Add errors as warnings if we have some valid data
            if errors:
                combined_results['warnings'] = errors

            return combined_results

        except Exception as error:
            logger.exception("Exception in EC2 estimation")
            return {'error': f"Failed to estimate EC2 service connections: {str(error)}"}


def merge_service_connection_results(service_results: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    """Merges service connection results from multiple services into a unified format.

    Args:
        service_results: Dictionary mapping service names to their results

    Returns:
        Dictionary with merged results organized by month, including any errors
    """
    merged_by_month = defaultdict(lambda: {
        'total': 0,
        'byService': {},
        'byTag': {},
        'byAccount': {}
    })

    errors = []
    warnings = []

    for service_name, accounts_data in service_results.items():
        # Check for errors in the service results
        if not isinstance(accounts_data, dict):
            error_msg = f"Invalid data format for {service_name}: {accounts_data}"
            logger.warning(error_msg)
            errors.append(error_msg)
            continue

        if 'error' in accounts_data:
            errors.append(f"{service_name}: {accounts_data['error']}")
            continue

        # Collect any warnings
        if 'warnings' in accounts_data:
            warnings.extend(accounts_data['warnings'])
            continue

        for account_id, monthly_data in accounts_data.items():
            # Skip warning entries
            if account_id == 'warnings':
                continue

            for month, data in monthly_data.items():
                total = round(data.get('serviceConnectionUsageTotal', 0), 2)
                by_tag = {
                    tag: round(val, 2) for tag, val in data.get('serviceConnectionUsageByTag', {}).items()
                }

                month_entry = merged_by_month[month]
                month_entry['total'] = round(month_entry['total'] + total, 2)

                # byService
                svc = month_entry['byService'].setdefault(service_name, {
                    'total': 0,
                    'byTag': {},
                    'byAccount': {},
                    'byAccountTag': {}
                })
                svc['total'] = round(svc['total'] + total, 2)
                svc['byAccount'][account_id] = round(svc['byAccount'].get(account_id, 0) + total, 2)

                # byService.byTag and byService.byAccountTag
                for tag, tag_val in by_tag.items():
                    svc['byTag'][tag] = round(svc['byTag'].get(tag, 0) + tag_val, 2)
                    acct_tag = svc['byAccountTag'].setdefault(account_id, {})
                    acct_tag[tag] = round(acct_tag.get(tag, 0) + tag_val, 2)

                # byTag
                for tag, tag_val in by_tag.items():
                    tag_entry = month_entry['byTag'].setdefault(tag, {'total': 0})
                    tag_entry['total'] = round(tag_entry['total'] + tag_val, 2)
                    tag_entry[service_name] = round(tag_entry.get(service_name, 0) + tag_val, 2)

                # byAccount
                acct_entry = month_entry['byAccount'].setdefault(account_id, {'total': 0})
                acct_entry['total'] = round(acct_entry['total'] + total, 2)
                acct_entry[service_name] = round(acct_entry.get(service_name, 0) + total, 2)

    result = dict(sorted(merged_by_month.items()))

    # Add errors and warnings to the result if there are any
    if errors:
        result['errors'] = errors

    if warnings:
        result['warnings'] = warnings

    return result


def assume_cross_account_sessions(base_session, role_name, account_ids, regions):
    if not account_ids:
        logger.info("No account IDs provided, using base session only")
        return [base_session]

    sessions = []
    regions = regions or [base_session.region_name or "us-east-1"]

    sts_client = base_session.client("sts")

    # Test base session identity
    try:
        caller_identity = sts_client.get_caller_identity()
        logger.info(f"Base session identity: {json.dumps(caller_identity)}")
    except Exception as e:
        logger.error(f"Failed to get caller identity: {e}")

    for account_id in account_ids:
        for region in regions:
            try:
                role_arn = f"arn:aws:iam::{account_id}:role/{role_name}"

                assumed = sts_client.assume_role(
                    RoleArn=role_arn,
                    RoleSessionName="CrossAccountSession"
                )

                creds = assumed['Credentials']

                # Create session with assumed credentials
                session = boto3.Session(
                    aws_access_key_id=creds['AccessKeyId'],
                    aws_secret_access_key=creds['SecretAccessKey'],
                    aws_session_token=creds['SessionToken'],
                    region_name=region
                )

                try:
                    verify_sts = session.client('sts')
                    verify_identity = verify_sts.get_caller_identity()
                except Exception as e:
                    logger.error(f"Failed to verify assumed session: {e}")

                sessions.append(session)
            except Exception as e:
                logger.error(f"Error assuming role in account {account_id}, region {region}: {e}", exc_info=True)

    return sessions


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    AWS Lambda function handler for estimating service connections.

    Args:
        event: Event data passed to the Lambda function, should contain:
            - start_date: Start date for metrics in ISO format (YYYY-MM-DD)
            - end_date: End date for metrics in ISO format (YYYY-MM-DD)
            - tags: Dictionary of tags used to filter resources (optional)
            - account_ids: List of AWS account IDs to assume into (optional)
            - regions: List of AWS regions to evaluate (optional)
            - role_name: Name of the IAM role to assume (optional)
        context: Runtime information provided by AWS Lambda.

    Returns:
        Response containing service connection estimates for EC2, Lambda, EKS, and ECS.
    """
    # Log the event for debugging purposes
    logger.info("Received event: %s", json.dumps(event))

    try:
        # Validate required parameters
        if 'start_date' not in event or 'end_date' not in event:
            error_msg = "Missing required parameters: start_date and end_date"
            logger.error(error_msg)
            return {
                'statusCode': 400,
                'body': json.dumps({'error': error_msg}),
                'headers': {'Content-Type': 'application/json'}
            }

        # Parse dates
        start_date = datetime.fromisoformat(event['start_date'].replace('Z', '+00:00'))
        end_date = datetime.fromisoformat(event['end_date'].replace('Z', '+00:00'))

        tags = event.get('tags', {})
        account_ids = event.get('account_ids', [])
        regions = event.get('regions', [])
        role_name = event.get('role_name', 'CrossAccountCloudWatchRole')

        logger.info(f"Estimating service connections from {start_date} to {end_date}")
        logger.info(f"Using tags: {tags}")
        logger.info(f"Target accounts: {account_ids}")
        logger.info(f"Target regions: {regions}")

        # Create sessions for all account/region combinations
        base_session = boto3.Session()
        sessions = assume_cross_account_sessions(base_session, role_name, account_ids, regions)

        # Estimate service connections for each service
        totals = {
            'EC2': EC2Estimator.estimate(sessions, start_date, end_date, tags),
            'Lambda': LambdaEstimator.estimate(sessions, start_date, end_date, tags),
            'EKS': EKSEstimator.estimate(sessions, start_date, end_date, tags),
            'ECS': ECSEstimator.estimate(sessions, start_date, end_date, tags),
        }

        # Merge results into unified format
        merged = merge_service_connection_results(totals)

        return {
            'statusCode': 200,
            'body': merged,
            'headers': {'Content-Type': 'application/json'}
        }

    except ValueError as e:
        error_msg = f"Invalid date format: {str(e)}"
        logger.error(error_msg)
        return {
            'statusCode': 400,
            'body': {'error': error_msg},
            'headers': {'Content-Type': 'application/json'}
        }

    except Exception as e:
        error_msg = f"An error occurred: {str(e)}"
        logger.exception(error_msg)
        return {
            'statusCode': 500,
            'body': {'error': error_msg},
            'headers': {'Content-Type': 'application/json'}
        }


if __name__ == "__main__":
    """Command line interface for testing the service connection estimator."""
    # Configure logging for CLI usage
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    # Parse command line arguments
    import argparse

    parser = argparse.ArgumentParser(description='Estimate AWS service connections')
    parser.add_argument('--start-date', type=str, required=True, help='Start date (YYYY-MM-DD)')
    parser.add_argument('--end-date', type=str, required=True, help='End date (YYYY-MM-DD)')
    parser.add_argument('--accounts', type=str, nargs='*', help='AWS account IDs')
    parser.add_argument('--regions', type=str, nargs='*', help='AWS regions')
    parser.add_argument('--role-name', type=str, default='CrossAccountCloudWatchRole',
                        help='IAM role name for cross-account access')
    parser.add_argument('--tags', type=str, help='JSON string of tags, e.g. \'{"env": ["prod", "dev"]}\'')
    parser.add_argument('--profile', type=str, help='AWS profile to use')

    args = parser.parse_args()

    # Parse tags from JSON string
    tags = {}
    if args.tags:
        try:
            tags = json.loads(args.tags)
            logger.info(f"Using tags: {tags}")
        except json.JSONDecodeError as e:
            logger.error(f"Error parsing tags JSON: {e}")
            logger.error("Tags should be formatted as a JSON string, e.g. '{\"env\": [\"prod\", \"dev\"]}'")
            exit(1)

    # Setup AWS session
    session = boto3.Session(profile_name=args.profile) if args.profile else boto3.Session()

    # Convert string dates to datetime
    start_date = datetime.fromisoformat(args.start_date)
    end_date = datetime.fromisoformat(args.end_date)

    # Create sessions for all account/region combinations
    sessions = assume_cross_account_sessions(session, args.role_name, args.accounts, args.regions)

    # Estimate service connections
    totals = {
        'EC2': EC2Estimator.estimate(sessions, start_date, end_date, tags),
        'Lambda': LambdaEstimator.estimate(sessions, start_date, end_date, tags),
        'EKS': EKSEstimator.estimate(sessions, start_date, end_date, tags),
        'ECS': ECSEstimator.estimate(sessions, start_date, end_date, tags),
    }

    # Merge and output results
    merged = merge_service_connection_results(totals)
    print(json.dumps(merged, indent=2))

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"ld_service_connections_{timestamp}.json"

    # Write the results to the file
    with open(filename, 'w') as f:
        json.dump(merged, f, indent=2)

    print(f"Results saved to {filename}")

